library(tidyverse)
library(haven)
library(janitor)
library(stringr)
#process the average population data
population<-read.csv("censusdata2020.csv")
#data cleaning. only need data for the community districts
pop<-population%>%
  clean_names()%>%
  select(year, geo_type, borough, name, pop1,cd_type) %>%
  subset(geo_type=="CD")%>%
  subset(cd_type=="CD")
#change the name so it can allign with other datasets when doing joins
pop$name <- ifelse(
  str_detect(pop$name, "Manhattan Community District"),
  str_c("MN", str_pad(str_extract(pop$name, "\\d+"), width = 2, pad = "0")),
  pop$name
)
pop$name <- ifelse(
  str_detect(pop$name, "Queens Community District"),
  str_c("QN", str_pad(str_extract(pop$name, "\\d+"), width = 2, pad = "0")),
  pop$name
)
pop$name <- ifelse(
  str_detect(pop$name, "Brooklyn Community District"),
  str_c("BK", str_pad(str_extract(pop$name, "\\d+"), width = 2, pad = "0")),
  pop$name
)
pop$name <- ifelse(
  str_detect(pop$name, "Bronx Community District"),
  str_c("BX", str_pad(str_extract(pop$name, "\\d+"), width = 2, pad = "0")),
  pop$name
)
pop$name <- ifelse(
  str_detect(pop$name, "Staten Island Community District"),
  str_c("SI", str_pad(str_extract(pop$name, "\\d+"), width = 2, pad = "0")),
  pop$name
)
#process income data
income<-read_csv("income_distribution_data.csv")
income<-income%>%
  clean_names()%>%
  subset(level=="Community District")%>%
  subset(year=="2017-2021")
#clean names and data types
income$geography <- gsub(" ([0-9])", "\\1", income$geography)
income$x20_000 <- as.numeric(gsub("%", "", income$x20_000)) / 100
income$x_20_001_40_000 <- as.numeric(gsub("%", "", income$x_20_001_40_000)) / 100
income$x_40_001_60_000 <- as.numeric(gsub("%", "", income$x_40_001_60_000)) / 100
income$x_60_001_100_000 <- as.numeric(gsub("%", "", income$x_60_001_100_000)) / 100
income$x_100_001_250_000 <- as.numeric(gsub("%", "", income$x_100_001_250_000)) / 100
income$x250_000 <- as.numeric(gsub("%", "", income$x250_000)) / 100
#calculate average income from brackets
income$aveinc<-as.numeric(income$x20_000)*10000+as.numeric(income$x_20_001_40_000)*30000+as.numeric(income$x_40_001_60_000)*50000+as.numeric(income$x_60_001_100_000)*80000+as.numeric(income$x_100_001_250_000)*175000+as.numeric(income$x250_000)*400000
#process litter bin data
lb<-read_csv("DSNY_Litter_Basket_Inventory_20231016.csv")
section<-read_csv("DSNY_Sections_20231016.csv")
district<-read_csv("DSNY_Districts.csv")
lbclean<-lb %>%
  clean_names() %>%
  select(section, streetname1, streetname2)
sectionclean<- section%>%
  clean_names() %>%
  select(section, district)
district<- district%>%
  clean_names()
#summarise data by district rather than section
lbcleansection<-full_join (lbclean, sectionclean, by="section")
lbcleansectionfinal<-lbcleansection%>%
  group_by(district)%>%
  summarise(totallb=n())
lbcleansectionfinal<-full_join(lbcleansectionfinal, district, by="district")
#clean names
lbcleansectionfinal$district <- ifelse(
  str_detect(lbcleansectionfinal$district, "BKN"),
  str_c("BK", str_pad(str_extract(lbcleansectionfinal$district, "\\d+"), width = 2, pad = "0")),
  lbcleansectionfinal$district
)
lbcleansectionfinal$district <- ifelse(
  str_detect(lbcleansectionfinal$district, "BKS"),
  str_c("BK", str_pad(str_extract(lbcleansectionfinal$district, "\\d+"), width = 2, pad = "0")),
  lbcleansectionfinal$district
)
lbcleansectionfinal$district <- ifelse(
  str_detect(lbcleansectionfinal$district, "QE"),
  str_c("QN", str_pad(str_extract(lbcleansectionfinal$district, "\\d+"), width = 2, pad = "0")),
  lbcleansectionfinal$district
)
lbcleansectionfinal$district <- ifelse(
  str_detect(lbcleansectionfinal$district, "QW"),
  str_c("QN", str_pad(str_extract(lbcleansectionfinal$district, "\\d+"), width = 2, pad = "0")),
  lbcleansectionfinal$district
)
colnames(income)[colnames(income) == "geography"] <- "district"
colnames(pop)[colnames(pop) == "name"] <- "district"
#merge data sets to export to QGIS
finaldata<-full_join(lbcleansectionfinal,income, by="district")
finaldata<-full_join(finaldata,pop, by="district")
finaldata<-finaldata%>%
  select(district, name, totallb, aveinc, pop1,fid,global_id,shape_area, shape_length, multipolygon)
finaldata$pop1 <- gsub(",", "", finaldata$pop1)
finaldata$pop1<- as.numeric(finaldata$pop1)
write_csv(finaldata,"final_data.csv")
visualization<-select(finaldata, district, totallb, aveinc)
write_csv(visualization,"visual.csv")
